-- ============================================
-- سكيما موقع "مكتبتي" (نسخة موسّعة) — نفّذها كاملة
-- في SQL Editor داخل مشروع Supabase الجديد
--
-- ⚠️ خطوات إلزامية لتفعيل تسجيل الدخول الحقيقي (اقرأها قبل التنفيذ):
-- 1) نفّذ هذا الملف كامل بالـ SQL Editor
-- 2) روح لـ Authentication → Users → Add user، وسوّي حسابك الشخصي
--    (إيميلك وكلمة سر تختارها) — هذا هو الحساب الوحيد اللي راح يقدر يعدّل الموقع
-- 3) روح لـ Authentication → Providers → Email، وأطفي خيار
--    "Allow new users to sign up" — هذا يمنع أي شخص ثاني يسوي حساب ويحصل صلاحية تعديل
-- 4) بالموقع نفسه: افتح القائمة الجانبية ☰ واضغط "تسجيل الدخول" بنفس الإيميل وكلمة السر
-- ============================================

create extension if not exists "pgcrypto";

-- ======== جدول الكتب ========
create table if not exists public.books (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author text not null,
  book_number text,                             -- اختياري (الكتب الرقمية ما إلها رقم فيزيائي)
  shelf_number text,                            -- اختياري (الكتب الرقمية ما إلها رف)
  image_url text,

  is_digital boolean not null default false,    -- كتاب رقمي (كندل) بدون نسخة ورقية
  download_url text,                            -- رابط تحميل/شراء الكتاب

  genre text,                                  -- تصنيف/نوع الكتاب
  reading_status text not null default 'unread' -- unread | reading | read
    check (reading_status in ('unread','reading','read')),
  rating smallint check (rating between 1 and 5),
  note text,                                    -- ملاحظة شخصية
  started_reading_at date,                      -- تاريخ بداية القراءة (رحلة الكتاب)
  finished_reading_at date,                     -- تاريخ الانتهاء من القراءة (رحلة الكتاب)

  is_borrowed boolean not null default false,
  borrowed_to text,
  borrowed_at date,

  last_viewed_at timestamptz,                   -- لآخر مرة انفتحت تفاصيله (لتأثير "الغبار")
  created_at timestamptz not null default now()
);

-- ======== جدول الروابط بين الكتب (خيوط الربط) ========
create table if not exists public.book_links (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.books(id) on delete cascade,
  linked_book_id uuid not null references public.books(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (book_id, linked_book_id)
);

-- ======== دفتر الاقتباسات (لكل كتاب عدة اقتباسات ملونة) ========
create table if not exists public.book_quotes (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.books(id) on delete cascade,
  text text not null,
  color text,
  created_at timestamptz not null default now()
);

-- ======== إعدادات الموقع (صف واحد فقط — لصورة الغلاف والتخصيص) ========
create table if not exists public.site_settings (
  id int primary key default 1 check (id = 1),
  cover_image_url text,
  theme jsonb                                   -- تخصيص الألوان/الخطوط/شكل العرض (JSON، اختياري)
);
alter table public.site_settings add column if not exists theme jsonb;

-- فهرس بحث
create index if not exists books_search_idx
  on public.books using gin (
    to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(author,'') || ' ' || coalesce(shelf_number,''))
  );

-- ======== RLS ========
alter table public.books enable row level security;
alter table public.book_links enable row level security;
alter table public.book_quotes enable row level security;
alter table public.site_settings enable row level security;

-- القراءة مفتوحة للجميع (يلزم لعمل الموقع العام ورابط "القراءة فقط")
-- الكتابة (إضافة/تعديل/حذف) تتطلب تسجيل دخول حقيقي عبر Supabase Auth
drop policy if exists "allow all books" on public.books;
drop policy if exists "public read books" on public.books;
drop policy if exists "admin insert books" on public.books;
drop policy if exists "admin update books" on public.books;
drop policy if exists "admin delete books" on public.books;
create policy "public read books" on public.books for select using (true);
create policy "admin insert books" on public.books for insert with check (auth.uid() is not null);
create policy "admin update books" on public.books for update using (auth.uid() is not null);
create policy "admin delete books" on public.books for delete using (auth.uid() is not null);

drop policy if exists "allow all book_links" on public.book_links;
drop policy if exists "public read book_links" on public.book_links;
drop policy if exists "admin insert book_links" on public.book_links;
drop policy if exists "admin update book_links" on public.book_links;
drop policy if exists "admin delete book_links" on public.book_links;
create policy "public read book_links" on public.book_links for select using (true);
create policy "admin insert book_links" on public.book_links for insert with check (auth.uid() is not null);
create policy "admin update book_links" on public.book_links for update using (auth.uid() is not null);
create policy "admin delete book_links" on public.book_links for delete using (auth.uid() is not null);

drop policy if exists "allow all book_quotes" on public.book_quotes;
drop policy if exists "public read book_quotes" on public.book_quotes;
drop policy if exists "admin insert book_quotes" on public.book_quotes;
drop policy if exists "admin update book_quotes" on public.book_quotes;
drop policy if exists "admin delete book_quotes" on public.book_quotes;
create policy "public read book_quotes" on public.book_quotes for select using (true);
create policy "admin insert book_quotes" on public.book_quotes for insert with check (auth.uid() is not null);
create policy "admin update book_quotes" on public.book_quotes for update using (auth.uid() is not null);
create policy "admin delete book_quotes" on public.book_quotes for delete using (auth.uid() is not null);

drop policy if exists "allow all site_settings" on public.site_settings;
drop policy if exists "public read site_settings" on public.site_settings;
drop policy if exists "admin update site_settings" on public.site_settings;
drop policy if exists "admin insert site_settings" on public.site_settings;
create policy "public read site_settings" on public.site_settings for select using (true);
create policy "admin insert site_settings" on public.site_settings for insert with check (auth.uid() is not null);
create policy "admin update site_settings" on public.site_settings for update using (auth.uid() is not null);

-- صف افتراضي لإعدادات الموقع
insert into public.site_settings (id, cover_image_url) values (1, null) on conflict (id) do nothing;

-- تحديث لحظي
alter publication supabase_realtime add table public.books;
alter publication supabase_realtime add table public.book_links;
alter publication supabase_realtime add table public.book_quotes;
alter publication supabase_realtime add table public.site_settings;

-- ======== مخزن صور الأغلفة ========
insert into storage.buckets (id, name, public)
values ('book-images', 'book-images', true)
on conflict (id) do nothing;

drop policy if exists "public read book-images" on storage.objects;
create policy "public read book-images"
  on storage.objects for select using (bucket_id = 'book-images');

drop policy if exists "public upload book-images" on storage.objects;
drop policy if exists "admin upload book-images" on storage.objects;
create policy "admin upload book-images"
  on storage.objects for insert with check (bucket_id = 'book-images' and auth.uid() is not null);

drop policy if exists "public update book-images" on storage.objects;
drop policy if exists "admin update book-images" on storage.objects;
create policy "admin update book-images"
  on storage.objects for update using (bucket_id = 'book-images' and auth.uid() is not null);

drop policy if exists "public delete book-images" on storage.objects;
drop policy if exists "admin delete book-images" on storage.objects;
create policy "admin delete book-images"
  on storage.objects for delete using (bucket_id = 'book-images' and auth.uid() is not null);
